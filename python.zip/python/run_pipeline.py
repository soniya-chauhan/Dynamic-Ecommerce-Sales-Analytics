import subprocess

subprocess.run(["python", "python/load_customers.py"])
subprocess.run(["python", "python/load_products.py"])
subprocess.run(["python", "python/load_orders.py"])
subprocess.run(["python", "python/load_order_items.py"])
subprocess.run(["python", "python/load_payments.py"])
subprocess.run(["python", "python/load_refunds.py"])

print("Pipeline completed!")