import pandas as pd
import pymysql
from dotenv import load_dotenv
import os

# Load .env from project root
load_dotenv(
    os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        ".env"
    ),
    override=True
)

# Read CSV
df = pd.read_csv("data/order_items.csv")

# Connect to MySQL
connection = pymysql.connect(
    host=os.getenv("DB_HOST"),
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    database=os.getenv("DB_NAME"),
    port=int(os.getenv("DB_PORT"))
)

cursor = connection.cursor()

# Remove old data
cursor.execute("DELETE FROM order_items")

# Insert latest CSV data
sql = """
INSERT INTO order_items
(order_item_id, order_id, product_id, quantity,
unit_price, discount_amount, line_total)
VALUES (%s, %s, %s, %s, %s, %s, %s)
"""

for _, row in df.iterrows():
    cursor.execute(sql, tuple(row))

connection.commit()

print(f"{len(df)} order items loaded successfully!")

cursor.close()
connection.close()