import pandas as pd
import pymysql
from dotenv import load_dotenv
import os

# Load .env from project root
load_dotenv(
    os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        ".env"
    ),
    override=True
)

# Read CSV
df = pd.read_csv("data/products.csv")

# Connect to MySQL
connection = pymysql.connect(
    host=os.getenv("DB_HOST"),
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    database=os.getenv("DB_NAME"),
    port=int(os.getenv("DB_PORT"))
)

cursor = connection.cursor()

# Remove old data
cursor.execute("DELETE FROM products")

# Insert latest CSV data
sql = """
INSERT INTO products
(product_id, sku, product_name, category, unit_cost, list_price)
VALUES (%s, %s, %s, %s, %s, %s)
"""

for _, row in df.iterrows():
    cursor.execute(sql, tuple(row))

connection.commit()

print(f"{len(df)} products loaded successfully!")

cursor.close()
connection.close()