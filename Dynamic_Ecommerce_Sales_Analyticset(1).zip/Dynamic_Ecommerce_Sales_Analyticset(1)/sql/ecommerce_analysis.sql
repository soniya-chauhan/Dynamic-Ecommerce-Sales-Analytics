USE ecommerce_analytics;

#TOTAL REVENUE

SELECT
    SUM(order_total) AS total_revenue
FROM orders
WHERE order_status <> 'cancelled';


#TOTAL ORDERS

SELECT
    COUNT(*) AS total_orders
FROM orders
WHERE order_status <> 'cancelled';


 3. AVERAGE ORDER VALUE

SELECT
    ROUND(
        SUM(order_total) / COUNT(*),
        2
    ) AS average_order_value
FROM orders
WHERE order_status <> 'cancelled';


#REVENUE BY PRODUCT CATEGORY

SELECT
    p.category,
    ROUND(SUM(oi.line_total), 2) AS revenue
FROM order_items oi
JOIN products p
    ON oi.product_id = p.product_id
JOIN orders o
    ON oi.order_id = o.order_id
WHERE o.order_status <> 'cancelled'
GROUP BY p.category
ORDER BY revenue DESC;


#TOP 10 PRODUCTS BY REVENUE

SELECT
    p.product_id,
    p.product_name,
    p.category,
    ROUND(SUM(oi.line_total), 2) AS revenue
FROM order_items oi
JOIN products p
    ON oi.product_id = p.product_id
JOIN orders o
    ON oi.order_id = o.order_id
WHERE o.order_status <> 'cancelled'
GROUP BY
    p.product_id,
    p.product_name,
    p.category
ORDER BY revenue DESC
LIMIT 10;


# REVENUE BY CUSTOMER SEGMENT

SELECT
    c.customer_segment,
    ROUND(SUM(o.order_total), 2) AS revenue
FROM orders o
JOIN customers c
    ON o.customer_id = c.customer_id
WHERE o.order_status <> 'cancelled'
GROUP BY c.customer_segment
ORDER BY revenue DESC;


# REVENUE BY COUNTRY

SELECT
    c.country_code,
    ROUND(SUM(o.order_total), 2) AS revenue
FROM orders o
JOIN customers c
    ON o.customer_id = c.customer_id
WHERE o.order_status <> 'cancelled'
GROUP BY c.country_code
ORDER BY revenue DESC;


8. MONTHLY REVENUE

SELECT
    DATE_FORMAT(ordered_at, '%Y-%m') AS month,
    ROUND(SUM(order_total), 2) AS revenue
FROM orders
WHERE order_status <> 'cancelled'
GROUP BY DATE_FORMAT(ordered_at, '%Y-%m')
ORDER BY month;



#. ORDERS BY STATUS

SELECT
    order_status,
    COUNT(*) AS order_count
FROM orders
GROUP BY order_status
ORDER BY order_count DESC;

#PAYMENT AMOUNT BY PAYMENT METHOD

SELECT
    payment_method,
    ROUND(SUM(amount), 2) AS payment_amount
FROM payments
WHERE payment_status = 'succeeded'
GROUP BY payment_method
ORDER BY payment_amount DESC;


# TOTAL REFUND AMOUNT

SELECT
    ROUND(SUM(amount), 2) AS total_refunds
FROM refunds;


# REFUND AMOUNT BY REASON

SELECT
    refund_reason,
    ROUND(SUM(amount), 2) AS refund_amount
FROM refunds
GROUP BY refund_reason
ORDER BY refund_amount DESC;



 13. PAYMENT STATUS

SELECT
    payment_status,
    COUNT(*) AS payment_count,
    ROUND(SUM(amount), 2) AS payment_amount
FROM payments
GROUP BY payment_status
ORDER BY payment_count DESC;


# CUSTOMERS BY SEGMENT

SELECT
    customer_segment,
    COUNT(*) AS customer_count
FROM customers
GROUP BY customer_segment
ORDER BY customer_count DESC;


#CUSTOMERS BY COUNTRY

SELECT
    country_code,
    COUNT(*) AS customer_count
FROM customers
GROUP BY country_code
ORDER BY customer_count DESC;